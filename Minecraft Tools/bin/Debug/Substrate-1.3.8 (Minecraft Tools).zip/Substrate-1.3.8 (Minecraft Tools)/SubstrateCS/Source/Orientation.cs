﻿using System;

namespace Substrate
{
    public class Orientation
    {
        public double Pitch { get; set; }
        public double Yaw { get; set; }
    }
}
