This library has been adapted by Jupisoft to fully support writing Minecraft 1.12.2- worlds.

The original code still pertains to it's original authors, except for the part added or changed by Jupisoft.

This source code should be included with the Minecraft Tools application designed by Jupisoft, to help any user to understand or modify any of the application and library features to it's liking.

Thanks a lot for reading and have a nice day.